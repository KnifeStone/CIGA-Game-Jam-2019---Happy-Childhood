window.__require = function e(t, i, o) {
function n(c, d) {
if (!i[c]) {
if (!t[c]) {
var r = c.split("/");
r = r[r.length - 1];
if (!t[r]) {
var s = "function" == typeof __require && __require;
if (!d && s) return s(r, !0);
if (a) return a(r, !0);
throw new Error("Cannot find module '" + c + "'");
}
}
var u = i[c] = {
exports: {}
};
t[c][0].call(u.exports, function(e) {
return n(t[c][1][e] || e);
}, u, u.exports, e, t, i, o);
}
return i[c].exports;
}
for (var a = "function" == typeof __require && __require, c = 0; c < o.length; c++) n(o[c]);
return n;
}({
AudioUtils: [ function(e, t, i) {
"use strict";
cc._RF.push(t, "1e9e8ZG/n9FSL2J4reYiV1e", "AudioUtils");
Object.defineProperty(i, "__esModule", {
value: !0
});
var o = e("./first/FirstAudioSetting"), n = function() {
function e() {}
e.playBgmMain = function() {
if ("true" == o.default.getAudioStatus()) {
cc.audioEngine.stopMusic();
var e = cc.loader.getRes("audio/bgm_main", cc.AudioClip);
cc.audioEngine.playMusic(e, !0);
}
};
e.playBgmGame = function() {
if ("true" == o.default.getAudioStatus()) {
cc.audioEngine.stopMusic();
var e = cc.loader.getRes("audio/bgm_game", cc.AudioClip);
cc.audioEngine.playMusic(e, !0);
}
};
e.playGamePass = function() {
cc.audioEngine.stopMusic();
this.playEffect("audio/game_pass");
};
e.playGameOver = function() {
cc.audioEngine.stopMusic();
this.playEffect("audio/game_over");
};
e.playClick = function() {
this.playEffect("audio/btn_click");
};
e.playEat = function(e) {
this.playEffect("audio/eat_" + e);
};
e.play203 = function() {
this.playEffect("audio/204");
};
e.play204 = function() {
this.playEffect("audio/204");
};
e.playOpen = function() {
this.playEffect("audio/open");
};
e.playCollision = function() {
var e = new Date().getTime();
if (!(0 != this.collisonTime && e - this.collisonTime < 500)) {
1 == this.first ? this.first = 2 : this.first = 1;
this.collisonTime = e;
this.playEffect("audio/collision_" + this.first);
}
};
e.playCollision3 = function() {
var e = new Date().getTime();
if (!(0 != this.collisonTime3 && e - this.collisonTime3 < 1e3)) {
this.collisonTime3 = e;
this.playEffect("audio/collision_3");
}
};
e.playEffect = function(e) {
var t = cc.loader.getRes(e, cc.AudioClip);
return cc.audioEngine.playEffect(t, !1);
};
e.collisonTime = 0;
e.first = 1;
e.collisonTime3 = 0;
return e;
}();
i.default = n;
cc._RF.pop();
}, {
"./first/FirstAudioSetting": "FirstAudioSetting"
} ],
BoxBean: [ function(e, t, i) {
"use strict";
cc._RF.push(t, "65090JvM3xP9rl7Z44nVsXi", "BoxBean");
Object.defineProperty(i, "__esModule", {
value: !0
});
var o = e("./Config"), n = function() {
function e(e, t) {
this.id = 0;
this.unit = 0;
this.group = "default";
this.zIndex = 0;
this.alive = !0;
this.boxSize = 0;
this.boxSizeH = 0;
this.patrol = 0;
this.speed = 0;
this.id = e;
this.key = t;
this.unit = o.default.roles[e].unit;
this.group = o.default.roles[e].group;
o.default.roles[e].boxSize ? this.boxSize = o.default.roles[e].boxSize : this.boxSize = this.unit - 1;
o.default.roles[e].boxSizeH && (this.boxSizeH = o.default.roles[e].boxSizeH - 1);
o.default.roles[e].speed && (this.speed = o.default.roles[e].speed);
this.zIndex = o.default.roles[e].zIndex;
}
e.prototype.checkObstacle = function() {
return "obstacle" == this.group;
};
e.prototype.checkEnemy = function() {
return "enemy" == this.group;
};
e.prototype.checkHero = function() {
return 1 == this.id || 2 == this.id;
};
e.prototype.checkFood = function() {
return "food" == this.group;
};
e.prototype.checkDevice = function() {
return "device" == this.group;
};
e.prototype.checkSoybean = function() {
return this.id >= 200 && this.id <= 202;
};
return e;
}();
i.default = n;
cc._RF.pop();
}, {
"./Config": "Config"
} ],
Box: [ function(e, t, i) {
"use strict";
cc._RF.push(t, "d70dbJ99LtAVrq9oxTzjZH7", "Box");
Object.defineProperty(i, "__esModule", {
value: !0
});
var o = e("../src/BoxBean"), n = e("../src/Config"), a = e("../src/AudioUtils"), c = cc._decorator, d = c.ccclass, r = c.property, s = function(e) {
__extends(t, e);
function t() {
var t = null !== e && e.apply(this, arguments) || this;
t.sprite = null;
t.bean = null;
t.ds = [ 0, 0, 0, 0 ];
t.firstD = -1;
t.pauseFrame = 0;
t.disabledFrame = 0;
t.openDoorName = "";
t.frameCount = 0;
t.frameIndex = 0;
return t;
}
t.prototype.initData = function(e) {
this.bean = e;
this.node.group = e.group;
this.node.width = e.unit;
this.node.height = e.unit;
this.node.zIndex = e.zIndex;
this.node.getComponent(cc.BoxCollider).size = cc.size(e.boxSize, e.boxSizeH ? e.boxSizeH : e.boxSize);
this.updatePosition();
this.updateView();
e.checkEnemy() && cc.game.on("pause-frame", function(e, t) {
this.bean.id == e && (this.pauseFrame = t);
}.bind(this), this);
if (204 == this.bean.id) this.rotateRepeat(); else if (1 == this.bean.id || 2 == this.bean.id) {
var t = this.node.getChildByName("bg");
this.node.active = !0;
t.getComponent(cc.Sprite).spriteFrame = cc.loader.getRes("bg/" + this.bean.id, cc.SpriteFrame);
this.heroBill(t);
}
};
t.prototype.updatePosition = function() {
this.node.x = this.bean.key.x * n.default.unit + n.default.unit / 2;
this.node.y = this.bean.key.y * n.default.unit + n.default.unit / 2;
};
t.prototype.onDestroy = function() {
cc.game.targetOff(this);
};
t.prototype.clearInput = function() {
this.ds[0] = 0;
this.ds[1] = 0;
this.ds[2] = 0;
this.ds[3] = 0;
};
t.prototype.inputDown = function(e) {
this.clearInput();
this.ds[e] = 1;
};
t.prototype.inputUp = function(e) {
this.ds[e] = 0;
};
t.prototype.updateView = function() {
if (101 == this.bean.id) {
var e, t = this.node.parent, i = void 0, o = function(t, i) {
if (t && 101 == e.getComponent("Box").bean.id) i.active = !1; else {
i.active = !0;
i.getComponent(cc.Sprite).spriteFrame = cc.loader.getRes("texture/101", cc.SpriteFrame);
}
};
e = t.getChildByName(this.bean.key.x - 1 + "-" + this.bean.key.y);
i = this.node.getChildByName("0");
o(e, i);
e = t.getChildByName(this.bean.key.x + "-" + (this.bean.key.y + 1));
i = this.node.getChildByName("1");
o(e, i);
e = t.getChildByName(this.bean.key.x + 1 + "-" + this.bean.key.y);
i = this.node.getChildByName("2");
o(e, i);
e = t.getChildByName(this.bean.key.x + "-" + (this.bean.key.y - 1));
i = this.node.getChildByName("3");
o(e, i);
} else this.sprite.spriteFrame = cc.loader.getRes("texture/" + this.bean.id, cc.SpriteFrame);
};
t.prototype.updateDs = function(e) {
var t = 0;
if (this.ds[0]) {
t = -1;
this.ds[2] && (t = 0);
} else this.ds[2] && (t = 1);
this.node.x += t * this.bean.speed;
var i = 0;
if (this.ds[1]) {
i = 1;
this.ds[3] && (i = 0);
} else this.ds[3] && (i = -1);
this.node.y += i * this.bean.speed;
};
t.prototype.updateEnemy = function(e) {
if (this.bean.checkEnemy()) {
for (var t = 0; t < this.ds.length; t++) if (this.ds[t]) return;
if (0 == this.bean.patrol) {
for (var i = -1; (i = Math.floor(4 * Math.random())) == this.firstD; ) ;
this.ds[i] = 1;
this.firstD = i;
} else if (1 == this.bean.patrol) {
i = 0;
-1 == this.firstD ? Math.random() < .5 && (i = 2) : i = 0 == this.firstD ? 2 : 0;
this.ds[i] = 1;
this.firstD = i;
} else if (2 == this.bean.patrol) {
i = 1;
-1 == this.firstD ? Math.random() < .5 && (i = 3) : i = 1 == this.firstD ? 3 : 1;
this.ds[i] = 1;
this.firstD = i;
}
}
};
t.prototype.updateFrame = function(e) {
this.frameCount++;
if (110 == this.bean.id) {
if (this.frameCount >= n.default.refreshPaustToolFrame) {
this.frameCount = 0;
this.newBox(this.bean.key, 210);
}
} else if (111 == this.bean.id) {
if (this.frameCount >= n.default.refreshPaustToolFrame) {
this.frameCount = 0;
this.newBox(this.bean.key, 211);
}
} else if (112 == this.bean.id) {
if (this.frameCount >= n.default.refreshPaustToolFrame) {
this.frameCount = 0;
this.newBox(this.bean.key, 212);
}
} else if ((1 == this.bean.id || 2 == this.bean.id || this.bean.checkEnemy()) && this.frameCount >= 20) {
this.frameCount = 0;
0 == this.frameIndex ? this.frameIndex = 1 : this.frameIndex = 0;
this.sprite.spriteFrame = cc.loader.getRes("frame/" + this.bean.id + "_" + this.frameIndex, cc.SpriteFrame);
}
};
t.prototype.newBox = function(e, t) {
if (!this.node.parent.getChildByName(e.x + "-" + e.y + "-" + t)) {
var i = cc.instantiate(this.node);
this.node.parent.addChild(i);
var n = i.getComponent("Box");
i.name = e.x + "-" + e.y + "-" + t;
n.initData(new o.default(t, e));
}
};
t.prototype.update = function(e) {
if (n.default.playing) if (this.disabledFrame > 0) {
this.node.opacity = 128;
this.disabledFrame--;
} else {
this.node.opacity = 255;
if (this.pauseFrame > 0) this.pauseFrame--; else {
this.updateFrame(e);
this.updateEnemy(e);
this.updateDs(e);
if (this.node.x < n.default.unit / 2) {
this.node.x = n.default.unit / 2;
if (this.bean.checkEnemy()) {
this.ds[0] = 0;
this.ds[2] = 0;
}
} else if (this.node.x > n.default.unit * (n.default.wNumber - .5)) {
this.node.x = n.default.unit * (n.default.wNumber - .5);
if (this.bean.checkEnemy()) {
this.ds[0] = 0;
this.ds[2] = 0;
}
}
if (this.node.y < n.default.unit / 2) {
this.node.y = n.default.unit / 2;
if (this.bean.checkEnemy()) {
this.ds[1] = 0;
this.ds[3] = 0;
}
} else if (this.node.y > n.default.unit * (n.default.hNumber - .5)) {
this.node.y = n.default.unit * (n.default.hNumber - .5);
if (this.bean.checkEnemy()) {
this.ds[1] = 0;
this.ds[3] = 0;
}
}
}
}
};
t.prototype.onCollisionStay = function(e, t) {
if (n.default.playing) {
var i = t.node.getComponent("Box"), o = e.node.getComponent("Box");
if (i.bean.checkHero() && o.bean.checkFood()) {
if (o.bean.id % 10 == i.bean.id) {
o.actionEat(i.bean.id);
211 == o.bean.id ? cc.game.emit("pause-frame", 12, n.default.pauseFrame) : 212 == o.bean.id ? cc.game.emit("pause-frame", 11, n.default.pauseFrame) : o.bean.checkSoybean() && n.default.soybeanNumber--;
} else if (203 == o.bean.id) {
o.actionEat(i.bean.id);
cc.game.emit("tool-203");
a.default.play203();
} else if (200 == o.bean.id) {
o.actionEat(i.bean.id);
n.default.soybeanNumber--;
} else if (210 == o.bean.id) {
o.actionEat(i.bean.id);
cc.game.emit("pause-frame", 10, n.default.pauseFrame);
}
console.log("豆子" + n.default.soybeanNumber);
if (n.default.soybeanNumber <= 0) {
cc.game.emit("show-game-pass");
cc.director.getCollisionManager().enabled = !1;
n.default.playing = !1;
}
} else if (!i.bean.checkHero() || !o.bean.checkEnemy() || o.bean.id % 10 != i.bean.id && 10 != o.bean.id) if (!o.bean.checkHero() || !i.bean.checkEnemy() || o.bean.id % 10 != i.bean.id && 10 != o.bean.id) {
(i.bean.checkHero() && o.bean.checkHero() || i.bean.checkHero() && o.bean.checkEnemy() || i.bean.checkEnemy() && o.bean.checkHero()) && a.default.playCollision3();
if (o.bean.checkDevice()) {
if (204 == o.bean.id) {
o.node.parent.children.forEach(function(e) {
var t = e.getComponent("Box");
if (t.bean.id == o.bean.id && t.node.name != o.node.name && t.disabledFrame <= 0) {
o.disabledFrame = 180;
t.disabledFrame = 180;
i.actionDelivery(t.node.position);
} else ;
});
return;
}
if (205 == o.bean.id) {
o.node.parent.children.forEach(function(e) {
var t = e.getComponent("Box");
206 != t.bean.id || t.actionShake(i.node.name);
});
return;
}
}
if (i.ds[2] && o.node.x - i.node.x > 0 && o.node.x - i.node.x < n.default.unit && i.node.x < o.node.x && Math.abs(i.node.x - o.node.x) > Math.abs(i.node.y - o.node.y)) {
i.node.x = o.node.x - o.bean.unit;
if (i.bean.checkEnemy()) {
i.ds[0] = 0;
i.ds[2] = 0;
}
} else if (i.ds[0] && i.node.x - o.node.x > 0 && i.node.x - o.node.x < n.default.unit && Math.abs(i.node.x - o.node.x) > Math.abs(i.node.y - o.node.y)) {
i.node.x = o.node.x + o.bean.unit;
if (i.bean.checkEnemy()) {
i.ds[0] = 0;
i.ds[2] = 0;
}
}
if (i.ds[1] && o.node.y - i.node.y > 0 && o.node.y - i.node.y < n.default.unit && Math.abs(i.node.y - o.node.y) > Math.abs(i.node.x - o.node.x)) {
i.node.y = o.node.y - o.bean.unit;
if (i.bean.checkEnemy()) {
i.ds[1] = 0;
i.ds[3] = 0;
}
} else if (i.ds[3] && i.node.y - o.node.y > 0 && i.node.y - o.node.y < n.default.unit && Math.abs(i.node.y - o.node.y) > Math.abs(i.node.x - o.node.x)) {
i.node.y = o.node.y + o.bean.unit;
if (i.bean.checkEnemy()) {
i.ds[1] = 0;
i.ds[3] = 0;
}
}
i.bean.checkHero() && o.bean.checkObstacle() && a.default.playCollision();
} else {
cc.game.emit("show-game-over");
cc.director.getCollisionManager().enabled = !1;
n.default.playing = !1;
} else {
cc.game.emit("show-game-over");
cc.director.getCollisionManager().enabled = !1;
n.default.playing = !1;
}
}
};
t.prototype.onCollisionExit = function(e, t) {
t.node.getComponent("Box");
var i = e.node.getComponent("Box");
if (i.bean.checkDevice() && 205 == i.bean.id) {
i.node.parent.children.forEach(function(e) {
var t = e.getComponent("Box");
206 != t.bean.id || t.stopShake();
});
} else ;
};
t.prototype.actionEat = function(e) {
a.default.playEat(e);
this.node.removeComponent(cc.BoxCollider);
var t = cc.scaleTo(.1, 0, 0), i = cc.sequence(t, cc.callFunc(function() {
this.node.removeFromParent();
}.bind(this)));
this.node.runAction(i);
};
t.prototype.actionDelivery = function(e) {
a.default.play204();
this.pauseFrame = 48;
var t = cc.scaleTo(.3, 0, 0), i = cc.callFunc(function() {
this.node.position = e;
}.bind(this)), o = cc.scaleTo(.5, 1, 1), n = cc.sequence(t, i, o);
this.node.runAction(n);
};
t.prototype.actionShake = function(e) {
if (this.openDoorName && this.openDoorName != e) {
this.stopShake();
a.default.playOpen();
this.node.getComponent(cc.BoxCollider).enabled = !1;
var t = cc.fadeOut(.3), i = cc.callFunc(function() {
this.node.removeFromParent();
}.bind(this)), o = cc.sequence(t, i);
o.setTag(123);
this.node.runAction(o);
}
if (!this.node.getActionByTag(123)) {
var n = cc.rotateTo(.1, -5), c = cc.rotateTo(.1, 0), d = cc.rotateTo(.1, 5), r = cc.rotateTo(.1, 0), s = cc.sequence(n, c, d, r), u = cc.repeatForever(s);
u.setTag(123);
this.node.runAction(u);
this.openDoorName = e;
}
};
t.prototype.stopShake = function() {
if (this.node.getActionByTag(123)) {
this.node.stopActionByTag(123);
this.openDoorName = "";
}
};
t.prototype.rotateRepeat = function() {
var e = cc.rotateBy(.1, 5), t = cc.repeatForever(e);
this.node.runAction(t);
};
t.prototype.heroBill = function(e) {
var t = cc.scaleTo(1, 1.3, 1.3), i = cc.delayTime(.2), o = cc.scaleTo(1, 1), n = cc.delayTime(.2), a = cc.sequence(t, i, o, n), c = cc.repeatForever(a);
e.runAction(c);
};
__decorate([ r(cc.Sprite) ], t.prototype, "sprite", void 0);
return t = __decorate([ d ], t);
}(cc.Component);
i.default = s;
cc._RF.pop();
}, {
"../src/AudioUtils": "AudioUtils",
"../src/BoxBean": "BoxBean",
"../src/Config": "Config"
} ],
Config: [ function(e, t, i) {
"use strict";
cc._RF.push(t, "8b48c6wQwtDm7DM9IkwIuNc", "Config");
Object.defineProperty(i, "__esModule", {
value: !0
});
var o = function() {
function e() {}
e.playing = !1;
e.checkedId = 0;
e.checkPatrol = 0;
e.checkSpeed = 1;
e.nowStage = 0;
e.stageDatas = [ {
"0-0": {
id: 101
},
"0-5": {
id: 101
},
"0-8": {
id: 101
},
"1-1": {
id: 101
},
"1-4": {
id: 101
},
"1-5": {
id: 101
},
"1-7": {
id: 101
},
"1-9": {
id: 101
},
"2-1": {
id: 101
},
"2-3": {
id: 101
},
"2-6": {
id: 101
},
"2-7": {
id: 101
},
"2-9": {
id: 101
},
"3-2": {
id: 101
},
"3-3": {
id: 101
},
"3-9": {
id: 101
},
"4-6": {
id: 101
},
"4-7": {
id: 101
},
"4-9": {
id: 101
},
"5-0": {
id: 101
},
"5-3": {
id: 101
},
"5-5": {
id: 101
},
"6-4": {
id: 101
},
"6-5": {
id: 101
},
"6-8": {
id: 101
},
"6-9": {
id: 101
},
"7-0": {
id: 101
},
"7-4": {
id: 101
},
"8-1": {
id: 101
},
"8-4": {
id: 101
},
"9-2": {
id: 101
},
"9-4": {
id: 101
},
"10-2": {
id: 101
},
"10-4": {
id: 101
},
"11-2": {
id: 101
},
"11-4": {
id: 101
},
"12-2": {
id: 101
},
"12-4": {
id: 101
},
"12-9": {
id: 101
},
"13-2": {
id: 101
},
"13-4": {
id: 101
},
"13-8": {
id: 101
},
"13-9": {
id: 101
},
"14-1": {
id: 101
},
"14-4": {
id: 101
},
"14-9": {
id: 101
},
"15-0": {
id: 101
},
"15-5": {
id: 101
},
"15-6": {
id: 101
},
"16-2": {
id: 101
},
"16-3": {
id: 101
},
"16-5": {
id: 101
},
"17-2": {
id: 101
},
"17-3": {
id: 101
},
"17-5": {
id: 101
},
"17-7": {
id: 101
},
"17-8": {
id: 101
},
"18-2": {
id: 101
},
"18-3": {
id: 101
},
"18-5": {
id: 101
},
"18-7": {
id: 101
},
"18-8": {
id: 101
},
"19-2": {
id: 101
},
"19-3": {
id: 101
},
"19-7": {
id: 101
},
"19-8": {
id: 101
},
"19-9": {
id: 101
},
"8-9": {
id: 101
},
"8-7": {
id: 101
},
"9-6": {
id: 101
},
"1-0": {
id: 204
},
"2-4": {
id: 200
},
"3-1": {
id: 202
},
"3-5": {
id: 206
},
"3-6": {
id: 200
},
"3-7": {
id: 200
},
"5-4": {
id: 201
},
"5-6": {
id: 201
},
"5-9": {
id: 200
},
"6-0": {
id: 205
},
"7-5": {
id: 210
},
"7-6": {
id: 201
},
"8-6": {
id: 202
},
"9-5": {
id: 202
},
"10-3": {
id: 200
},
"10-5": {
id: 201
},
"11-3": {
id: 200
},
"12-3": {
id: 200
},
"13-5": {
id: 202
},
"14-3": {
id: 201
},
"14-5": {
id: 201
},
"15-3": {
id: 201
},
"15-4": {
id: 201
},
"16-4": {
id: 200
},
"16-9": {
id: 202
},
"17-0": {
id: 200
},
"17-4": {
id: 200
},
"17-6": {
id: 200
},
"17-9": {
id: 202
},
"18-0": {
id: 200
},
"18-4": {
id: 200
},
"18-6": {
id: 200
},
"18-9": {
id: 204
},
"19-0": {
id: 200
},
"19-1": {
id: 205
},
"19-6": {
id: 200
},
"9-7": {
id: 202
},
"12-8": {
id: 200
},
"11-8": {
id: 200
},
"11-7": {
id: 200
},
"12-7": {
id: 200
},
"6-3": {
id: 12,
patrol: 1,
speed: 3
},
"7-9": {
id: 12,
patrol: 2,
speed: 1
},
"15-9": {
id: 11,
patrol: 2,
speed: 1
},
"9-9": {
id: 11,
patrol: 2
},
"13-7": {
id: 12,
patrol: 2
},
"11-5": {
id: 1,
speed: 3
},
"12-5": {
id: 2,
speed: 3
}
}, {
"0-5": {
id: 101
},
"0-7": {
id: 101
},
"0-8": {
id: 101
},
"0-9": {
id: 101
},
"1-0": {
id: 101
},
"1-5": {
id: 101
},
"1-9": {
id: 101
},
"2-0": {
id: 101
},
"2-2": {
id: 101
},
"2-3": {
id: 101
},
"2-5": {
id: 101
},
"2-7": {
id: 101
},
"2-9": {
id: 101
},
"3-0": {
id: 101
},
"3-1": {
id: 101
},
"3-2": {
id: 101
},
"3-5": {
id: 101
},
"3-8": {
id: 101
},
"3-9": {
id: 101
},
"4-0": {
id: 101
},
"4-5": {
id: 101
},
"4-6": {
id: 101
},
"5-0": {
id: 101
},
"5-2": {
id: 101
},
"5-3": {
id: 101
},
"5-5": {
id: 101
},
"5-6": {
id: 101
},
"6-0": {
id: 101
},
"6-2": {
id: 101
},
"6-3": {
id: 101
},
"6-5": {
id: 101
},
"6-8": {
id: 101
},
"6-9": {
id: 101
},
"7-0": {
id: 101
},
"7-5": {
id: 101
},
"7-9": {
id: 101
},
"8-5": {
id: 101
},
"8-7": {
id: 101
},
"8-8": {
id: 101
},
"9-1": {
id: 101
},
"9-4": {
id: 101
},
"10-4": {
id: 101
},
"11-2": {
id: 101
},
"11-3": {
id: 101
},
"11-4": {
id: 110
},
"11-5": {
id: 101
},
"12-6": {
id: 101
},
"12-7": {
id: 101
},
"12-9": {
id: 101
},
"13-0": {
id: 101
},
"13-1": {
id: 101
},
"13-2": {
id: 101
},
"13-6": {
id: 101
},
"14-4": {
id: 101
},
"14-5": {
id: 101
},
"14-6": {
id: 101
},
"14-8": {
id: 101
},
"14-9": {
id: 101
},
"15-0": {
id: 101
},
"15-4": {
id: 101
},
"15-7": {
id: 101
},
"16-0": {
id: 101
},
"16-4": {
id: 101
},
"16-7": {
id: 101
},
"16-8": {
id: 101
},
"17-0": {
id: 101
},
"17-1": {
id: 101
},
"17-4": {
id: 101
},
"18-0": {
id: 101
},
"18-5": {
id: 101
},
"18-6": {
id: 101
},
"18-7": {
id: 101
},
"19-0": {
id: 101
},
"19-1": {
id: 101
},
"19-2": {
id: 101
},
"19-3": {
id: 101
},
"19-5": {
id: 101
},
"19-6": {
id: 101
},
"19-7": {
id: 101
},
"0-4": {
id: 205
},
"1-8": {
id: 206
},
"2-1": {
id: 203
},
"2-8": {
id: 204
},
"4-1": {
id: 201
},
"6-6": {
id: 211
},
"7-8": {
id: 202
},
"9-2": {
id: 200
},
"9-8": {
id: 202
},
"10-2": {
id: 200
},
"10-6": {
id: 200
},
"10-7": {
id: 200
},
"10-9": {
id: 202
},
"11-0": {
id: 201
},
"11-8": {
id: 200
},
"14-7": {
id: 205
},
"15-1": {
id: 200
},
"15-2": {
id: 200
},
"15-5": {
id: 200
},
"15-6": {
id: 200
},
"15-8": {
id: 204
},
"16-1": {
id: 200
},
"16-2": {
id: 200
},
"16-5": {
id: 200
},
"16-6": {
id: 200
},
"17-5": {
id: 201
},
"17-7": {
id: 202
},
"17-8": {
id: 202
},
"18-1": {
id: 210
},
"0-0": {
id: 12,
patrol: 2,
speed: 1
},
"4-9": {
id: 10,
patrol: 2,
speed: 1
},
"5-1": {
id: 11,
patrol: 1,
speed: 1
},
"5-9": {
id: 12,
patrol: 2,
speed: 1
},
"8-4": {
id: 11,
patrol: 1,
speed: 1
},
"9-9": {
id: 10,
speed: 1
},
"10-8": {
id: 10,
speed: 1
},
"14-3": {
id: 11,
patrol: 2,
speed: 1
},
"0-6": {
id: 2,
speed: 3
},
"19-4": {
id: 1,
speed: 3
}
}, {
"0-9": {
id: 101
},
"0-8": {
id: 101
},
"0-7": {
id: 101
},
"0-6": {
id: 101
},
"0-0": {
id: 101
},
"0-1": {
id: 101
},
"0-2": {
id: 101
},
"0-3": {
id: 101
},
"2-9": {
id: 101
},
"2-8": {
id: 101
},
"2-7": {
id: 101
},
"2-6": {
id: 101
},
"2-5": {
id: 101
},
"2-0": {
id: 101
},
"2-1": {
id: 101
},
"2-2": {
id: 101
},
"5-1": {
id: 101
},
"5-0": {
id: 101
},
"5-4": {
id: 101
},
"5-7": {
id: 101
},
"5-8": {
id: 101
},
"7-8": {
id: 101
},
"7-7": {
id: 101
},
"7-6": {
id: 101
},
"7-5": {
id: 101
},
"7-4": {
id: 101
},
"7-3": {
id: 101
},
"7-2": {
id: 101
},
"7-1": {
id: 101
},
"9-6": {
id: 101
},
"9-7": {
id: 101
},
"9-8": {
id: 101
},
"10-8": {
id: 101
},
"11-8": {
id: 101
},
"10-9": {
id: 112
},
"12-9": {
id: 101
},
"10-4": {
id: 101
},
"11-4": {
id: 101
},
"10-3": {
id: 101
},
"10-2": {
id: 101
},
"10-1": {
id: 101
},
"12-0": {
id: 101
},
"12-2": {
id: 101
},
"13-2": {
id: 101
},
"13-4": {
id: 111
},
"14-5": {
id: 101
},
"14-4": {
id: 101
},
"14-3": {
id: 101
},
"14-2": {
id: 101
},
"14-1": {
id: 101
},
"14-0": {
id: 101
},
"15-1": {
id: 101
},
"15-2": {
id: 101
},
"15-3": {
id: 101
},
"15-4": {
id: 101
},
"15-5": {
id: 101
},
"15-0": {
id: 110
},
"15-9": {
id: 101
},
"15-8": {
id: 101
},
"19-6": {
id: 101
},
"18-6": {
id: 101
},
"18-4": {
id: 101
},
"19-4": {
id: 101
},
"1-8": {
id: 200
},
"1-7": {
id: 200
},
"3-9": {
id: 202
},
"3-8": {
id: 202
},
"3-7": {
id: 202
},
"4-9": {
id: 202
},
"4-8": {
id: 202
},
"4-7": {
id: 202
},
"3-2": {
id: 201
},
"3-1": {
id: 201
},
"3-0": {
id: 201
},
"4-2": {
id: 201
},
"4-1": {
id: 201
},
"4-0": {
id: 201
},
"6-1": {
id: 202
},
"6-8": {
id: 201
},
"13-9": {
id: 202
},
"14-9": {
id: 201
},
"11-7": {
id: 200
},
"10-7": {
id: 200
},
"10-6": {
id: 200
},
"11-6": {
id: 200
},
"13-0": {
id: 202
},
"15-6": {
id: 205
},
"18-5": {
id: 206
},
"19-5": {
id: 200
},
"19-7": {
id: 201
},
"19-8": {
id: 201
},
"19-3": {
id: 202
},
"19-2": {
id: 202
},
"17-2": {
id: 205
},
"1-6": {
id: 11,
patrol: 2
},
"1-3": {
id: 12,
patrol: 2
},
"8-5": {
id: 11,
patrol: 1
},
"11-9": {
id: 11,
patrol: 1
},
"11-0": {
id: 12,
patrol: 2
},
"16-9": {
id: 10,
patrol: 2
},
"16-8": {
id: 12,
patrol: 2
},
"17-8": {
id: 10,
patrol: 2
},
"0-5": {
id: 1,
speed: 3
},
"0-4": {
id: 2,
speed: 3
}
} ];
e.editData = {
"7-6": {
id: 1,
speed: 3
},
"11-6": {
id: 2,
speed: 3
}
};
e.wNumber = 20;
e.hNumber = 10;
e.unit = 60;
e.speedHero = 3;
e.speedEnemy = 1;
e.pauseFrame = 150;
e.refreshPaustToolFrame = 150;
e.soybeanNumber = 0;
e.roles = {
1: {
unit: 56,
group: "hero",
zIndex: 99,
speed: e.speedHero
},
2: {
unit: 56,
group: "hero",
zIndex: 99,
speed: e.speedHero
},
10: {
unit: 56,
boxSizeH: 28,
group: "enemy",
zIndex: 88,
speed: e.speedEnemy
},
11: {
unit: 56,
boxSizeH: 28,
group: "enemy",
zIndex: 88,
speed: e.speedEnemy
},
12: {
unit: 56,
group: "enemy",
zIndex: 88,
speed: e.speedEnemy
},
101: {
unit: 60,
group: "obstacle",
zIndex: 66
},
110: {
unit: 60,
group: "default",
zIndex: 66
},
111: {
unit: 60,
group: "default",
zIndex: 66
},
112: {
unit: 60,
group: "default",
zIndex: 66
},
200: {
unit: 30,
group: "food",
zIndex: 77
},
201: {
unit: 30,
group: "food",
zIndex: 77
},
202: {
unit: 30,
group: "food",
zIndex: 77
},
203: {
unit: 56,
group: "food",
zIndex: 77,
boxSize: 1
},
204: {
unit: 56,
group: "device",
zIndex: 77,
boxSize: 1
},
205: {
unit: 56,
group: "device",
zIndex: 77,
boxSize: 1
},
206: {
unit: 60,
group: "obstacle",
zIndex: 77
},
210: {
unit: 56,
group: "food",
zIndex: 77,
boxSize: 5
},
211: {
unit: 56,
group: "food",
zIndex: 77,
boxSize: 5
},
212: {
unit: 56,
group: "food",
zIndex: 77,
boxSize: 5
}
};
return e;
}();
i.default = o;
window.Config = o;
cc._RF.pop();
}, {} ],
Edit: [ function(e, t, i) {
"use strict";
cc._RF.push(t, "c75adZ9acFOp7rn2akx/ZVI", "Edit");
Object.defineProperty(i, "__esModule", {
value: !0
});
var o = e("../src/Config"), n = e("../src/BoxBean"), a = cc._decorator, c = a.ccclass, d = a.property, r = function(e) {
__extends(t, e);
function t() {
var t = null !== e && e.apply(this, arguments) || this;
t.layoutMap = null;
t.prefabBox = null;
return t;
}
t.prototype.onLoad = function() {
var e = this;
this.layoutMap.on(cc.Node.EventType.TOUCH_START, function(t) {
var i = e.layoutMap.convertToNodeSpace(t.getLocation()), n = i.x / o.default.unit;
n = Math.floor(n);
var a = i.y / o.default.unit;
a = Math.floor(a);
new cc.Vec2(n, a);
console.log("坐标x:" + n + ":y:" + a);
e.newBox(cc.v2(n, a));
e.updateMapView();
}, this.layoutMap);
for (var t = JSON.parse(JSON.stringify(o.default.editData)), i = 0; i < o.default.wNumber; i++) for (var a = 0; a < o.default.hNumber; a++) {
var c = t[i + "-" + a];
if (c) {
var d = cc.instantiate(this.prefabBox);
this.layoutMap.addChild(d);
var r = d.getComponent(d.name);
d.name = i + "-" + a;
var s = new n.default(c.id, cc.v2(i, a));
c.patrol && (s.patrol = c.patrol);
c.speed && (s.speed = c.speed);
r.initData(s);
}
}
};
t.prototype.onClickTest = function() {
var e = {};
this.layoutMap.children.forEach(function(t) {
var i = t.getComponent("Box").bean;
e[t.name] = {
id: i.id
};
i.patrol && (e[t.name].patrol = i.patrol);
i.speed && (e[t.name].speed = i.speed);
});
o.default.editData = e;
o.default.stageDatas.push(e);
o.default.nowStage = o.default.stageDatas.length - 1;
console.log(JSON.stringify(e));
cc.director.loadScene("Game");
};
t.prototype.onClickBack = function() {
cc.director.loadScene("Main");
};
t.prototype.onClickClear = function() {
this.layoutMap.removeAllChildren();
};
t.prototype.newBox = function(e) {
var t = this.layoutMap.getChildByName(e.x + "-" + e.y);
if (t) 0 == o.default.checkedId ? t.removeFromParent() : cc.game.emit("show-toast", "已存在"); else {
var i = this.checkLimit(o.default.checkedId);
switch (o.default.checkedId) {
case 0:
return;

case 1:
case 2:
case 206:
if (i >= 1) {
cc.game.emit("show-toast", "这个家伙，不能放更多了");
return;
}
break;

case 204:
case 205:
if (i >= 2) {
cc.game.emit("show-toast", "这个家伙，不能放更多了");
return;
}
break;

case 10:
case 11:
case 12:
if (i >= 3) {
cc.game.emit("show-toast", "这个家伙，不能放更多了");
return;
}
}
if (0 != o.default.checkedId) {
var a = cc.instantiate(this.prefabBox);
this.layoutMap.addChild(a);
var c = a.getComponent(a.name);
a.name = e.x + "-" + e.y;
var d = new n.default(o.default.checkedId, e);
c.initData(d);
if (d.checkEnemy()) {
d.patrol = o.default.checkPatrol;
d.speed = o.default.checkSpeed;
}
}
}
};
t.prototype.updateMapView = function() {
this.layoutMap.children.forEach(function(e) {
101 == e.getComponent("Box").bean.id && e.getComponent("Box").updateView();
});
};
t.prototype.checkLimit = function(e) {
var t = 0;
this.layoutMap.children.forEach(function(i) {
i.getComponent("Box").bean.id == e && t++;
});
return t;
};
__decorate([ d(cc.Node) ], t.prototype, "layoutMap", void 0);
__decorate([ d(cc.Prefab) ], t.prototype, "prefabBox", void 0);
return t = __decorate([ c ], t);
}(cc.Component);
i.default = r;
cc._RF.pop();
}, {
"../src/BoxBean": "BoxBean",
"../src/Config": "Config"
} ],
FirstAnim: [ function(e, t, i) {
"use strict";
cc._RF.push(t, "63472HdmoRLfrIrQIqNPaR4", "FirstAnim");
Object.defineProperty(i, "__esModule", {
value: !0
});
var o = cc._decorator, n = o.ccclass, a = o.property, c = function(e) {
__extends(t, e);
function t() {
var t = null !== e && e.apply(this, arguments) || this;
t.animName = "";
return t;
}
t.prototype.onEnable = function() {
this.node.stopAllActions();
this.animName && this[this.animName + ""]();
};
t.prototype.fadeInOrOut = function() {
var e = cc.fadeOut(.8), t = cc.delayTime(1), i = cc.fadeIn(.4), o = cc.delayTime(1), n = cc.sequence(e, t, i, o), a = cc.repeatForever(n);
this.node.runAction(a);
};
t.prototype.scale0t1 = function() {
this.node.scale = 0;
var e = cc.scaleTo(1, 1, 1).easing(cc.easeBackOut());
this.node.runAction(e);
};
t.Scale0t1 = function(e) {
e.scale = 0;
var t = cc.scaleTo(1, 1, 1).easing(cc.easeBackOut());
e.runAction(t);
};
__decorate([ a(String) ], t.prototype, "animName", void 0);
return t = __decorate([ n ], t);
}(cc.Component);
i.default = c;
cc._RF.pop();
}, {} ],
FirstAudioSetting: [ function(e, t, i) {
"use strict";
cc._RF.push(t, "63384cQm7xARa50RX+KOJGW", "FirstAudioSetting");
var o = this && this.__extends || function() {
var e = Object.setPrototypeOf || {
__proto__: []
} instanceof Array && function(e, t) {
e.__proto__ = t;
} || function(e, t) {
for (var i in t) t.hasOwnProperty(i) && (e[i] = t[i]);
};
return function(t, i) {
e(t, i);
function o() {
this.constructor = t;
}
t.prototype = null === i ? Object.create(i) : (o.prototype = i.prototype, new o());
};
}(), n = this && this.__decorate || function(e, t, i, o) {
var n, a = arguments.length, c = a < 3 ? t : null === o ? o = Object.getOwnPropertyDescriptor(t, i) : o;
if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) c = Reflect.decorate(e, t, i, o); else for (var d = e.length - 1; d >= 0; d--) (n = e[d]) && (c = (a < 3 ? n(c) : a > 3 ? n(t, i, c) : n(t, i)) || c);
return a > 3 && c && Object.defineProperty(t, i, c), c;
};
Object.defineProperty(i, "__esModule", {
value: !0
});
var a = e("../AudioUtils"), c = cc._decorator, d = c.ccclass, r = c.property, s = function(e) {
o(t, e);
function t() {
var t = null !== e && e.apply(this, arguments) || this;
t.spriteFrameOpen = null;
t.spriteFrameClose = null;
t.sprite = null;
return t;
}
i = t;
t.prototype.onLoad = function() {
this.updateView();
};
t.prototype.onClick = function() {
"true" == i.getAudioStatus() ? i.setAudioStatus("false") : i.setAudioStatus("true");
this.updateView();
};
t.getAudioStatus = function() {
var e = cc.sys.localStorage.getItem("audio-status");
e || (e = "true");
return e;
};
t.setAudioStatus = function(e) {
cc.sys.localStorage.setItem("audio-status", e);
};
t.prototype.updateView = function() {
if ("true" == i.getAudioStatus()) {
"Main" == cc.director.getScene().name ? a.default.playBgmMain() : a.default.playBgmGame();
this.sprite.spriteFrame = this.spriteFrameOpen;
} else {
cc.audioEngine.stopMusic();
this.sprite.spriteFrame = this.spriteFrameClose;
}
};
var i;
n([ r(cc.SpriteFrame) ], t.prototype, "spriteFrameOpen", void 0);
n([ r(cc.SpriteFrame) ], t.prototype, "spriteFrameClose", void 0);
n([ r(cc.Sprite) ], t.prototype, "sprite", void 0);
return t = i = n([ d ], t);
}(cc.Component);
i.default = s;
cc._RF.pop();
}, {
"../AudioUtils": "AudioUtils"
} ],
FirstClickAudio: [ function(e, t, i) {
"use strict";
cc._RF.push(t, "73471dmMLpCQZi2rLYxt30O", "FirstClickAudio");
Object.defineProperty(i, "__esModule", {
value: !0
});
var o = e("../AudioUtils"), n = cc._decorator, a = n.ccclass, c = (n.property, function(e) {
__extends(t, e);
function t() {
return null !== e && e.apply(this, arguments) || this;
}
t.prototype.onClick = function() {
o.default.playClick();
};
return t = __decorate([ a ], t);
}(cc.Component));
i.default = c;
cc._RF.pop();
}, {
"../AudioUtils": "AudioUtils"
} ],
FirstClickScene: [ function(e, t, i) {
"use strict";
cc._RF.push(t, "cc295X9NdlKZLb8AXk5S8B7", "FirstClickScene");
Object.defineProperty(i, "__esModule", {
value: !0
});
var o = cc._decorator, n = o.ccclass, a = o.property, c = function(e) {
__extends(t, e);
function t() {
var t = null !== e && e.apply(this, arguments) || this;
t.sceneName = "";
return t;
}
t.prototype.onClick = function() {
cc.director.loadScene(this.sceneName);
};
__decorate([ a(String) ], t.prototype, "sceneName", void 0);
return t = __decorate([ n ], t);
}(cc.Component);
i.default = c;
cc._RF.pop();
}, {} ],
FirstFrameAnim__: [ function(e, t, i) {
"use strict";
cc._RF.push(t, "1926dWZP9ZA9LXcWB/VQSnx", "FirstFrameAnim__");
Object.defineProperty(i, "__esModule", {
value: !0
});
var o = cc._decorator, n = o.ccclass, a = o.property, c = function(e) {
__extends(t, e);
function t() {
var t = null !== e && e.apply(this, arguments) || this;
t.sprite = null;
t.text = "hello";
t.frameCount = 0;
t.frameIndex = 0;
return t;
}
t.prototype.update = function(e) {
this.frameCount++;
if (this.frameCount >= 20) {
this.frameCount = 0;
0 == this.frameIndex ? this.frameIndex = 1 : this.frameIndex = 0;
this.sprite.spriteFrame = cc.loader.getRes("frame/" + this.text + "_" + this.frameIndex, cc.SpriteFrame);
}
};
__decorate([ a(cc.Sprite) ], t.prototype, "sprite", void 0);
__decorate([ a ], t.prototype, "text", void 0);
return t = __decorate([ n ], t);
}(cc.Component);
i.default = c;
cc._RF.pop();
}, {} ],
FirstWheelLayout: [ function(e, t, i) {
"use strict";
cc._RF.push(t, "4c928qlzCRBhqJRW9xsFYa6", "FirstWheelLayout");
Object.defineProperty(i, "__esModule", {
value: !0
});
var o = cc._decorator, n = o.ccclass, a = o.property, c = function(e) {
__extends(t, e);
function t() {
var t = null !== e && e.apply(this, arguments) || this;
t.label = null;
t.texts = [ "策划 - 光合作用的西行妖", "美术 - 钱安仪", "音效 - 丁一峰", "程序 - 江志锋" ];
t.updateFrame = 180;
t.index = 0;
t.nowFrame = 0;
return t;
}
t.prototype.onLoad = function() {
this.action();
};
t.prototype.update = function(e) {
if (this.nowFrame >= this.updateFrame) {
this.nowFrame = 0;
this.index++;
this.index >= this.texts.length && (this.index = 0);
this.action();
} else this.nowFrame++;
};
t.prototype.action = function() {
this.node.stopAllActions();
this.label.string = this.texts[this.index];
this.node.opacity = 0;
var e = cc.fadeIn(.7), t = cc.delayTime(1.5), i = cc.fadeOut(.8), o = cc.sequence(e, t, i);
this.node.runAction(o);
};
__decorate([ a(cc.Label) ], t.prototype, "label", void 0);
return t = __decorate([ n ], t);
}(cc.Component);
i.default = c;
cc._RF.pop();
}, {} ],
Game: [ function(e, t, i) {
"use strict";
cc._RF.push(t, "acddeqGWNVDmrbu/ilG1rqM", "Game");
Object.defineProperty(i, "__esModule", {
value: !0
});
var o = e("../src/Config"), n = e("../src/BoxBean"), a = e("../src/AudioUtils"), c = cc._decorator, d = c.ccclass, r = c.property, s = function(e) {
__extends(t, e);
function t() {
var t = null !== e && e.apply(this, arguments) || this;
t.prefabBox = null;
t.layoutMap = null;
t.heroA = null;
t.heroB = null;
t.dataMaps = null;
return t;
}
t.prototype.onLoad = function() {
cc.game.emit("show-toast", "欢乐谷 - " + (o.default.nowStage + 1), 2);
this.initListener();
cc.game.on("tool-203", function() {
if (this.heroA && this.heroB && this.heroA.bean.alive && this.heroA.bean.alive) {
var e = cc.v2(this.heroA.node.x, this.heroA.node.y), t = cc.v2(this.heroB.node.x, this.heroB.node.y);
this.heroA.actionDelivery(t);
this.heroB.actionDelivery(e);
}
}.bind(this), this);
cc.game.on("tool-204", function(e) {
if (this.heroA && this.heroB && this.heroA.bean.alive && this.heroA.bean.alive) {
var t = cc.v2(this.heroA.node.x, this.heroA.node.y), i = cc.v2(this.heroB.node.x, this.heroB.node.y);
this.heroA.actionDelivery(i);
this.heroB.actionDelivery(t);
}
}.bind(this), this);
cc.game.on("game-reset", function() {
this.initData();
}.bind(this), this);
this.initData();
};
t.prototype.initData = function() {
a.default.playBgmGame();
cc.director.getCollisionManager().enabled = !0;
o.default.playing = !0;
o.default.soybeanNumber = 0;
this.heroA = null;
this.heroB = null;
this.dataMaps = [];
this.layoutMap.cleanup();
this.layoutMap.removeAllChildren();
var e = o.default.stageDatas[o.default.nowStage];
e = JSON.parse(JSON.stringify(e));
for (var t = 0; t < o.default.wNumber; t++) for (var i = 0; i < o.default.hNumber; i++) {
var c = e[t + "-" + i];
if (c) {
var d = cc.instantiate(this.prefabBox);
this.layoutMap.addChild(d);
var r = d.getComponent("Box");
d.name = t + "-" + i;
var s = new n.default(c.id, cc.v2(t, i));
c.patrol && (s.patrol = c.patrol);
c.speed && (s.speed = c.speed);
r.initData(s);
1 == c.id ? this.heroA = r : 2 == c.id && (this.heroB = r);
s.checkSoybean() && o.default.soybeanNumber++;
this.dataMaps.push(r);
}
}
this.updateMapView();
};
t.prototype.updateMapView = function() {
this.layoutMap.children.forEach(function(e) {
101 == e.getComponent("Box").bean.id && e.getComponent("Box").updateView();
});
};
t.prototype.initListener = function() {
cc.systemEvent.on(cc.SystemEvent.EventType.KEY_DOWN, this.onKeyDown, this);
cc.systemEvent.on(cc.SystemEvent.EventType.KEY_UP, this.onKeyUp, this);
};
t.prototype.onDestroy = function() {
cc.game.targetOff(this);
cc.systemEvent.off(cc.SystemEvent.EventType.KEY_DOWN, this.onKeyDown, this);
cc.systemEvent.off(cc.SystemEvent.EventType.KEY_UP, this.onKeyUp, this);
};
t.prototype.onKeyDown = function(e) {
switch (e.keyCode) {
case cc.macro.KEY.a:
this.heroA.inputDown(0);
break;

case cc.macro.KEY.w:
this.heroA.inputDown(1);
break;

case cc.macro.KEY.d:
this.heroA.inputDown(2);
break;

case cc.macro.KEY.s:
this.heroA.inputDown(3);
break;

case cc.macro.KEY.left:
this.heroB.inputDown(0);
break;

case cc.macro.KEY.up:
this.heroB.inputDown(1);
break;

case cc.macro.KEY.right:
this.heroB.inputDown(2);
break;

case cc.macro.KEY.down:
this.heroB.inputDown(3);
}
};
t.prototype.onKeyUp = function(e) {
switch (e.keyCode) {
case cc.macro.KEY.a:
this.heroA.inputUp(0);
break;

case cc.macro.KEY.w:
this.heroA.inputUp(1);
break;

case cc.macro.KEY.d:
this.heroA.inputUp(2);
break;

case cc.macro.KEY.s:
this.heroA.inputUp(3);
break;

case cc.macro.KEY.left:
this.heroB.inputUp(0);
break;

case cc.macro.KEY.up:
this.heroB.inputUp(1);
break;

case cc.macro.KEY.right:
this.heroB.inputUp(2);
break;

case cc.macro.KEY.down:
this.heroB.inputUp(3);
}
};
t.prototype.update = function(e) {};
__decorate([ r(cc.Prefab) ], t.prototype, "prefabBox", void 0);
__decorate([ r(cc.Node) ], t.prototype, "layoutMap", void 0);
return t = __decorate([ d ], t);
}(cc.Component);
i.default = s;
cc._RF.pop();
}, {
"../src/AudioUtils": "AudioUtils",
"../src/BoxBean": "BoxBean",
"../src/Config": "Config"
} ],
ItemStage: [ function(e, t, i) {
"use strict";
cc._RF.push(t, "330963oWDZC87pk8RtyDnG+", "ItemStage");
Object.defineProperty(i, "__esModule", {
value: !0
});
var o = cc._decorator, n = o.ccclass, a = o.property, c = function(e) {
__extends(t, e);
function t() {
var t = null !== e && e.apply(this, arguments) || this;
t.label = null;
t.stage = 0;
return t;
}
t.prototype.initData = function(e) {
this.stage = e;
this.label.string = "" + (e + 1);
};
t.prototype.onClick = function() {
cc.game.emit("select-stage", this.stage);
};
__decorate([ a(cc.Label) ], t.prototype, "label", void 0);
return t = __decorate([ n ], t);
}(cc.Component);
i.default = c;
cc._RF.pop();
}, {} ],
LayoutGameOver: [ function(e, t, i) {
"use strict";
cc._RF.push(t, "a5ef9JnJ05OqpNnLbTTsLhW", "LayoutGameOver");
Object.defineProperty(i, "__esModule", {
value: !0
});
var o = e("./AudioUtils"), n = e("./first/FirstAnim"), a = cc._decorator, c = a.ccclass, d = a.property, r = function(e) {
__extends(t, e);
function t() {
var t = null !== e && e.apply(this, arguments) || this;
t.layout = null;
return t;
}
t.prototype.onLoad = function() {
this.node.removeFromParent();
cc.game.addPersistRootNode(this.node);
this.node.active = !1;
var e = this.node.getComponent(cc.Widget);
e.horizontalCenter = 0;
e.verticalCenter = 0;
cc.game.on("show-game-over", this.show, this);
};
t.prototype.onDestroy = function() {
cc.game.targetOff(this);
};
t.prototype.show = function() {
this.node.active = !0;
n.default.Scale0t1(this.layout);
o.default.playGameOver();
};
t.prototype.onClickSubmit = function() {
this.node.active = !1;
cc.director.loadScene("Main");
};
t.prototype.onClickReset = function() {
this.node.active = !1;
cc.game.emit("game-reset");
};
t.prototype.onClickStage = function() {
this.node.active = !1;
cc.game.emit("show-stage");
};
__decorate([ d(cc.Node) ], t.prototype, "layout", void 0);
return t = __decorate([ c ], t);
}(cc.Component);
i.default = r;
cc._RF.pop();
}, {
"./AudioUtils": "AudioUtils",
"./first/FirstAnim": "FirstAnim"
} ],
LayoutGamePass: [ function(e, t, i) {
"use strict";
cc._RF.push(t, "a3891qnO/pMX5ocJKXZ/YU5", "LayoutGamePass");
Object.defineProperty(i, "__esModule", {
value: !0
});
var o = e("./AudioUtils"), n = e("./first/FirstAnim"), a = cc._decorator, c = a.ccclass, d = a.property, r = function(e) {
__extends(t, e);
function t() {
var t = null !== e && e.apply(this, arguments) || this;
t.layout = null;
return t;
}
t.prototype.onLoad = function() {
this.node.removeFromParent();
cc.game.addPersistRootNode(this.node);
this.node.active = !1;
var e = this.node.getComponent(cc.Widget);
e.horizontalCenter = 0;
e.verticalCenter = 0;
cc.game.on("show-game-pass", this.show, this);
};
t.prototype.onDestroy = function() {
cc.game.targetOff(this);
};
t.prototype.show = function() {
this.node.active = !0;
n.default.Scale0t1(this.layout);
o.default.playGamePass();
};
t.prototype.onClickBack = function() {
this.node.active = !1;
cc.director.loadScene("Main");
};
t.prototype.onClickStage = function() {
this.node.active = !1;
cc.game.emit("show-stage");
};
__decorate([ d(cc.Node) ], t.prototype, "layout", void 0);
return t = __decorate([ c ], t);
}(cc.Component);
i.default = r;
cc._RF.pop();
}, {
"./AudioUtils": "AudioUtils",
"./first/FirstAnim": "FirstAnim"
} ],
LayoutPatrol: [ function(e, t, i) {
"use strict";
cc._RF.push(t, "b3933VFwYBDcrq/PeDTRmOk", "LayoutPatrol");
Object.defineProperty(i, "__esModule", {
value: !0
});
var o = e("./Config"), n = cc._decorator, a = n.ccclass, c = (n.property, function(e) {
__extends(t, e);
function t() {
return null !== e && e.apply(this, arguments) || this;
}
t.prototype.onChecked = function(e, t) {
o.default.checkPatrol = parseInt(e.node.name);
};
return t = __decorate([ a ], t);
}(cc.Component));
i.default = c;
cc._RF.pop();
}, {
"./Config": "Config"
} ],
LayoutSpeed: [ function(e, t, i) {
"use strict";
cc._RF.push(t, "03b26ZH6rlE2Kg31qCJV932", "LayoutSpeed");
Object.defineProperty(i, "__esModule", {
value: !0
});
var o = e("./Config"), n = cc._decorator, a = n.ccclass, c = (n.property, function(e) {
__extends(t, e);
function t() {
return null !== e && e.apply(this, arguments) || this;
}
t.prototype.onChecked = function(e, t) {
o.default.checkSpeed = parseInt(e.node.name);
};
return t = __decorate([ a ], t);
}(cc.Component));
i.default = c;
cc._RF.pop();
}, {
"./Config": "Config"
} ],
LayoutStage: [ function(e, t, i) {
"use strict";
cc._RF.push(t, "0df0fZ/5oxOkrRRQUGfSqs8", "LayoutStage");
Object.defineProperty(i, "__esModule", {
value: !0
});
var o = e("./Config"), n = e("./first/FirstAnim"), a = cc._decorator, c = a.ccclass, d = a.property, r = function(e) {
__extends(t, e);
function t() {
var t = null !== e && e.apply(this, arguments) || this;
t.layout = null;
t.container = null;
t.prefabStage = null;
return t;
}
t.prototype.onLoad = function() {
this.node.removeFromParent();
cc.game.addPersistRootNode(this.node);
this.node.active = !1;
var e = this.node.getComponent(cc.Widget);
e.horizontalCenter = 0;
e.verticalCenter = 0;
cc.game.on("show-stage", this.show, this);
cc.game.on("select-stage", function(e) {
this.node.active = !1;
o.default.nowStage = e;
cc.director.loadScene("Game");
}.bind(this), this);
};
t.prototype.onEnable = function() {
this.container.removeAllChildren();
o.default.stageDatas.forEach(function(e, t) {
var i = cc.instantiate(this.prefabStage);
this.container.addChild(i);
i.getComponent(this.prefabStage.name).initData(t);
}.bind(this));
};
t.prototype.onDestroy = function() {
cc.game.targetOff(this);
};
t.prototype.show = function() {
this.node.active = !0;
n.default.Scale0t1(this.layout);
};
t.prototype.onClickBack = function() {
this.node.active = !1;
cc.director.loadScene("Main");
};
__decorate([ d(cc.Node) ], t.prototype, "layout", void 0);
__decorate([ d(cc.Node) ], t.prototype, "container", void 0);
__decorate([ d(cc.Prefab) ], t.prototype, "prefabStage", void 0);
return t = __decorate([ c ], t);
}(cc.Component);
i.default = r;
cc._RF.pop();
}, {
"./Config": "Config",
"./first/FirstAnim": "FirstAnim"
} ],
LayoutToast: [ function(e, t, i) {
"use strict";
cc._RF.push(t, "bfbc9G5LMNMFI/3Orn1TStN", "LayoutToast");
Object.defineProperty(i, "__esModule", {
value: !0
});
var o = cc._decorator, n = o.ccclass, a = o.property, c = function(e) {
__extends(t, e);
function t() {
var t = null !== e && e.apply(this, arguments) || this;
t.layout = null;
t.container = null;
return t;
}
t.prototype.onLoad = function() {
this.node.removeFromParent();
cc.game.addPersistRootNode(this.node);
this.layout.active = !1;
var e = this.node.getComponent(cc.Widget);
e.horizontalCenter = 0;
e.verticalCenter = 0;
cc.game.on("show-toast", this.toast, this);
};
t.prototype.onDestroy = function() {
cc.game.targetOff(this);
};
t.prototype.toast = function(e, t) {
this.container.cleanup();
this.container.removeAllChildren();
console.log("toast:", e, t);
var i = cc.instantiate(this.layout);
i.active = !0;
i.scale = 0;
var o = cc.scaleTo(.1, 1, 1), n = cc.fadeOut(.1), a = cc.sequence(o, cc.delayTime(t || 1), n, cc.callFunc(function() {
i.removeFromParent();
i.destroy();
}.bind(i)));
i.runAction(a);
i.getChildByName("LabelTitle").getComponent(cc.Label).string = "" + e;
this.container.addChild(i);
};
__decorate([ a(cc.Node) ], t.prototype, "layout", void 0);
__decorate([ a(cc.Node) ], t.prototype, "container", void 0);
return t = __decorate([ n ], t);
}(cc.Component);
i.default = c;
cc._RF.pop();
}, {} ],
LayoutTool: [ function(e, t, i) {
"use strict";
cc._RF.push(t, "60757fPd0tEx45XiGUuKU26", "LayoutTool");
Object.defineProperty(i, "__esModule", {
value: !0
});
var o = e("./Config"), n = cc._decorator, a = n.ccclass, c = n.property, d = function(e) {
__extends(t, e);
function t() {
var t = null !== e && e.apply(this, arguments) || this;
t.item = null;
t.toggleContainer = null;
return t;
}
t.prototype.onLoad = function() {
this.item.parent = null;
};
t.prototype.start = function() {
o.default.checkedId = 0;
var e = this;
cc.loader.loadResDir("texture", cc.SpriteFrame, function(t, i) {
console.log(t, i);
i.forEach(function(t) {
e.newBox(t);
});
}.bind(this));
};
t.prototype.onChecked = function(e, t) {
o.default.checkedId = parseInt(e.node.name);
console.log(o.default.checkedId);
};
t.prototype.newBox = function(e) {
var t = cc.instantiate(this.item);
t.name = e.name;
t.getChildByName("Sprite").getComponent(cc.Sprite).spriteFrame = e;
this.toggleContainer.addChild(t);
};
__decorate([ c(cc.Node) ], t.prototype, "item", void 0);
__decorate([ c(cc.Node) ], t.prototype, "toggleContainer", void 0);
return t = __decorate([ a ], t);
}(cc.Component);
i.default = d;
cc._RF.pop();
}, {
"./Config": "Config"
} ],
Main: [ function(e, t, i) {
"use strict";
cc._RF.push(t, "d99423Hc+dIOJAUQBUIGuAt", "Main");
var o = this && this.__extends || function() {
var e = Object.setPrototypeOf || {
__proto__: []
} instanceof Array && function(e, t) {
e.__proto__ = t;
} || function(e, t) {
for (var i in t) t.hasOwnProperty(i) && (e[i] = t[i]);
};
return function(t, i) {
e(t, i);
function o() {
this.constructor = t;
}
t.prototype = null === i ? Object.create(i) : (o.prototype = i.prototype, new o());
};
}(), n = this && this.__decorate || function(e, t, i, o) {
var n, a = arguments.length, c = a < 3 ? t : null === o ? o = Object.getOwnPropertyDescriptor(t, i) : o;
if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) c = Reflect.decorate(e, t, i, o); else for (var d = e.length - 1; d >= 0; d--) (n = e[d]) && (c = (a < 3 ? n(c) : a > 3 ? n(t, i, c) : n(t, i)) || c);
return a > 3 && c && Object.defineProperty(t, i, c), c;
};
Object.defineProperty(i, "__esModule", {
value: !0
});
var a = e("../src/Config"), c = e("../src/AudioUtils"), d = cc._decorator, r = d.ccclass, s = d.property, u = function(e) {
o(t, e);
function t() {
var t = null !== e && e.apply(this, arguments) || this;
t.nodeHome = null;
t.btnStart = null;
t.btnCreate = null;
return t;
}
t.prototype.onLoad = function() {
cc.loader.loadResDir("", function() {
c.default.playBgmMain();
this.showBtn();
}.bind(this));
a.default.playing = !1;
a.default.checkPatrol = 0;
a.default.checkSpeed = 0;
a.default.checkedId = 0;
this.btnStart.active = !1;
this.btnCreate.active = !1;
this.nodeHome.y = 0;
};
t.prototype.onClickStart = function() {
cc.game.emit("show-stage");
};
t.prototype.onClickEdit = function() {
cc.director.loadScene("Edit");
};
t.prototype.showBtn = function() {
var e = cc.moveTo(.3, this.nodeHome.x, 130);
this.nodeHome.runAction(e);
this.btnStart.active = !0;
this.btnStart.scale = 0;
var t = cc.scaleTo(.6, 1, 1);
this.btnStart.runAction(t);
this.btnCreate.active = !0;
this.btnCreate.opacity = 0;
var i = cc.fadeTo(.8, 255);
this.btnCreate.runAction(i);
};
n([ s(cc.Node) ], t.prototype, "nodeHome", void 0);
n([ s(cc.Node) ], t.prototype, "btnStart", void 0);
n([ s(cc.Node) ], t.prototype, "btnCreate", void 0);
return t = n([ r ], t);
}(cc.Component);
i.default = u;
cc._RF.pop();
}, {
"../src/AudioUtils": "AudioUtils",
"../src/Config": "Config"
} ]
}, {}, [ "Box", "ItemStage", "Edit", "Game", "Main", "AudioUtils", "BoxBean", "Config", "LayoutGameOver", "LayoutGamePass", "LayoutPatrol", "LayoutSpeed", "LayoutStage", "LayoutToast", "LayoutTool", "FirstAnim", "FirstAudioSetting", "FirstClickAudio", "FirstClickScene", "FirstFrameAnim__", "FirstWheelLayout" ]);